package ode;

public enum Type {
    EMPTY, PREDATOR, PREY
}
